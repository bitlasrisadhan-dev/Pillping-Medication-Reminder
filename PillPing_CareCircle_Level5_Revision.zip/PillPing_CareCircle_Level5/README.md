# PillPing CareCircle — Level 5 Engineering Revision

This revision is based on the latest 74/100 evaluation feedback. It preserves the existing PillPing visual design while changing the persistence layer to normalized relational tables, adding a server-side missed-dose scheduler, protecting session-changing requests with CSRF tokens, moving the session secret to environment configuration, and splitting browser logic into modules.

## Technology
- Frontend: HTML5, CSS3, JavaScript ES modules
- Backend: Node.js 18+ and Express
- Database: SQLite with relational tables and foreign keys
- Authentication: bcrypt password hashing and server-side sessions stored in SQLite
- Security: CSRF token validation, session regeneration, HTTP-only/SameSite cookies, input validation, request-size limits, security headers and login/register rate limits
- Scheduling: Node.js server-side interval scheduler
- Tests: Node.js built-in test runner and Supertest

## Windows 11 setup
1. Install Node.js 22 LTS (your installed v22.23.5 is suitable).
2. Extract this ZIP.
3. Open the extracted `PillPing_CareCircle_Level5` folder in VS Code.
4. Copy `.env.example` to a new file named `.env` in the project root.
5. In `.env`, replace `SESSION_SECRET` with a long random value. Keep `.env` private; do not upload it to GitHub.
6. Open Terminal > New Terminal in VS Code.
7. Install packages:

   ```bash
   npm install
   ```

8. Run the automated tests (API tests plus validation and priority-engine unit tests):

   ```bash
   npm test
   ```

9. Start the application:

   ```bash
   npm start
   ```

10. Open `http://localhost:3000` in Chrome or Edge.

Keep the terminal running while using PillPing. Stop the server with `Ctrl + C`.

## Database structure
- `users`: account identities and password hashes
- `user_preferences`: theme and selected day
- `medicines`: one row per medicine
- `medicine_times`: one row per daily reminder time
- `dose_records`: one row per medicine, date and scheduled time
- `alerts`: separate caregiver alert records with follow-up priority
- `daily_summaries`: daily adherence totals
- `notification_log`: delivered/browser reminder keys
- `care_notes`: caregiver notes
- `audit_logs`: important account and care actions
- `sessions`: persistent server sessions

The earlier `user_data` JSON blob is no longer used. If the existing database contains the previous `user_data` table, the app migrates its records to the relational tables on startup and keeps the legacy table for recovery/audit.

## Server-side missed-dose scheduler
The scheduler runs every minute while the Node.js process is running. It creates dose rows for each active medicine time, marks a pending dose missed after the configured grace period, and creates one alert per dose. The default grace period is 15 minutes and can be changed through `MISSED_DOSE_GRACE_MINUTES` in `.env`.

The scheduler works while the patient browser is closed, provided the server process and host remain running. It pauses if the Node.js process or host stops. Production deployment should use a supervised process and a durable scheduler/queue.

## Follow-up priority algorithm
PillPing calculates an operational caregiver follow-up score from recent missed-dose count, consecutive missed-dose streak and overdue time. It is a queue-prioritisation aid only; it is not a medical risk score and must not be used to change medicine doses. Unit tests cover score bounds and priority tier movement.

## Frontend modules
- `js/app.js`: application startup and event wiring
- `js/modules/api.js`: same-origin API requests and CSRF token handling
- `js/modules/store.js`: server state loading/saving and daily history
- `js/modules/ui.js`: patient and caregiver rendering
- `js/modules/medicines.js`: medicine form and dose confirmation
- `js/modules/reminders.js`: browser reminder display and server reminder check
- `js/modules/reports.js`: weekly report and CSV/print export
- `js/modules/date-time.js`: date/time and HTML escaping helpers

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/auth/csrf` | Obtain the session CSRF token |
| POST | `/auth/register` | Create an account |
| POST | `/auth/login` | Authenticate a user |
| GET | `/auth/me` | Check the signed-in session |
| POST | `/auth/logout` | End the session |
| GET | `/api/data` | Load normalized medicine, dose, alert and summary data |
| PUT | `/api/data` | Validate and sync the patient's current dashboard data into relational tables |
| POST | `/api/reminders/check` | Run an immediate server-side missed-dose sweep |
| PATCH | `/api/alerts/:id/acknowledge` | Acknowledge an alert owned by the signed-in account |
| GET | `/api/health` | Check API/database availability |

## Test coverage
Run `npm test`. Tests cover registration, password hashing, duplicate email handling, CSRF enforcement, session persistence, logout, user data isolation, relational table writes, nested input validation, scheduler idempotency, alert acknowledgement and follow-up priority calculations.

## Honest limitations
- This is an academic prototype, not a certified medical device.
- The follow-up priority score is an operational queue aid, not clinical guidance.
- It does not send SMS, WhatsApp messages or phone calls. Those need a consent-based notification provider.
- The scheduler runs while the server process is alive; it is not a managed cloud job service.
- Before public deployment, use HTTPS, a strong `.env` secret, backup/restore procedures, monitoring and a security review.
- Sample medicines and timings are illustrative only. Use schedules confirmed by the patient's clinician.
