require('dotenv').config();
const { createApp } = require('./backend/app');
const { startScheduler } = require('./backend/services/scheduler');

const port = Number(process.env.PORT || 3000);
const app = createApp();
const server = app.listen(port, () => {
  console.log(`PillPing server ready at http://localhost:${port}`);
  startScheduler(app.locals.db, {
    intervalMs: Number(process.env.SCHEDULER_INTERVAL_MS || 60000),
    graceMinutes: Number(process.env.MISSED_DOSE_GRACE_MINUTES || 15)
  });
});

function shutdown(signal) {
  console.log(`${signal} received. Closing PillPing...`);
  server.close(() => {
    app.locals.db.close();
    process.exit(0);
  });
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
