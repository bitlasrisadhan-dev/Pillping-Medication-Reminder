# Implementation response to the latest evaluation (74/100)

| Latest feedback | Revision in this version | Evidence to verify |
|---|---|---|
| Missed-dose engine only runs when the browser calls a check | Added an independent Node.js scheduler that runs every minute on the server | Keep server terminal open, close browser, wait until a due dose passes grace period, then reopen and inspect alert |
| Medicine/Dose data stored as one JSON blob | Normalized users, medicines, medicine_times, dose_records, alerts and daily_summaries tables | Inspect SQLite schema and automated relational persistence test |
| Secret was hardcoded | SESSION_SECRET is read from `.env`; production startup fails if it is missing | Inspect `.env.example` and server startup logic |
| Session lacked CSRF protection | Added per-session CSRF token, timing-safe check and same-origin check on write requests | Automated test verifies mutation without token returns 403 |
| Frontend app.js was monolithic | Split API, state, UI, medicine, reminder, report and date helpers into ES modules | Inspect `public/js/modules` (project `js/modules`) |
| Innovation needed more engineering depth | Added a tested follow-up priority calculation based on recent missed count, consecutive streak and overdue duration | Inspect `backend/services/priority-engine.js` and tests |
| Existing UI was a strength | Kept original Navy/Lavender and high-contrast dashboard layout | Compare running UI with prior version |

## Test run checklist before resubmission
1. `npm install`
2. `npm test`
3. `npm start`
4. Register an account and sign in.
5. Add a medicine with at least two scheduled times.
6. Confirm a dose and verify the dose history and percentage update.
7. Leave one dose unconfirmed; keep the server running and close the browser.
8. Wait until at least 15 minutes after that dose's scheduled time, then reopen the dashboard; verify an alert exists.
9. Acknowledge the alert and verify it disappears from the open alert list.
10. Check CSV export and Print / Save as PDF.

Do not claim the scheduler test or browser workflow has passed until it has been run on the target laptop.
