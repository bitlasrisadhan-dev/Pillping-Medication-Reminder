// Load pure business-logic test suites so `npm test` runs them with API integration tests.
require('../backend/services/validation.test');
require('../backend/services/priority-engine.test');
