import {initializeAuth} from './modules/auth.js';
import {getState,saveState,loadState,archiveCurrentDay,advanceToNextDay} from './modules/store.js';
import {setTheme,renderAll,toast,selectAll} from './modules/ui.js';
import {addTimeRow,addMedicine,markTaken} from './modules/medicines.js';
import {checkMissedDoses,startReminderChecks,requestNotificationPermission} from './modules/reminders.js';
import {exportReport,printReport} from './modules/reports.js';
import {apiRequest} from './modules/api.js';
const $=selector=>document.querySelector(selector);

async function refreshDashboard(){await loadState();renderAll();setTheme(getState().theme);}
async function saveAndRefresh(){await saveState();renderAll();}
function switchViews(){
 selectAll('.role-button').forEach(button=>button.addEventListener('click',()=>{
  selectAll('.role-button').forEach(item=>item.classList.toggle('active',item===button));
  $('#patient-view').classList.toggle('hidden',button.dataset.view!=='patient');
  $('#caregiver-view').classList.toggle('hidden',button.dataset.view!=='caregiver');
 }));
}
function bindDashboard(){
 $('#theme-toggle').addEventListener('click',async()=>{
  const state=getState();state.theme=state.theme==='dark'?'light':'dark';setTheme(state.theme);
  try{await saveState();}catch(error){toast(error.message);}
 });
 $('#add-time').addEventListener('click',()=>{if(selectAll('.time-row').length>=4){toast('You can add up to four reminder times.');return;}addTimeRow();});
 $('#medicine-form').addEventListener('submit',addMedicine);
 $('#medicine-list').addEventListener('click',event=>{const button=event.target.closest('[data-take]');if(button)markTaken(button.dataset.take,button.dataset.time);});
 $('#check-alerts').addEventListener('click',()=>checkMissedDoses(true));
 $('#alert-list').addEventListener('click',async event=>{
  const button=event.target.closest('[data-resolve]');if(!button)return;
  try{await apiRequest(`/api/alerts/${encodeURIComponent(button.dataset.resolve)}/acknowledge`,{method:'PATCH',body:'{}'});await refreshDashboard();toast('Alert acknowledged.');}
  catch(error){toast(error.message);}
 });
 $('#export-report').addEventListener('click',exportReport);
 $('#print-report').addEventListener('click',printReport);
 $('#enable-notifications').addEventListener('click',requestNotificationPermission);
 $('#next-day').addEventListener('click',async()=>{
  if(!confirm('Archive this day and move to the next calendar day? Previous dose records will be retained.'))return;
  advanceToNextDay();
  try{await saveState();await refreshDashboard();toast('Moved to the next day. Previous history was retained.');}
  catch(error){toast(error.message);}
 });
 switchViews();
}

async function onAuthenticated(){
 bindDashboard();renderAll();setTheme(getState().theme);startReminderChecks();
 // Refresh server-side scheduler results while the dashboard is open.
 setInterval(async()=>{try{await refreshDashboard();}catch(error){console.warn('Dashboard refresh:',error.message);}},60000);
}

document.addEventListener('DOMContentLoaded',async()=>{
 try{await initializeAuth(onAuthenticated);}
 catch(error){$('#auth-message').textContent=error.message;}
});
