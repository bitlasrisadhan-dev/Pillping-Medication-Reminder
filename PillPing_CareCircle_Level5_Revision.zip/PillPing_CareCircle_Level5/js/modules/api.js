let csrfToken='';
export function setCsrfToken(token){csrfToken=typeof token==='string'?token:'';}
export async function initializeCsrf(){
  const response=await fetch('/auth/csrf',{credentials:'same-origin'});
  const body=await response.json();
  if(!response.ok)throw new Error(body.error||'Could not initialise secure session.');
  setCsrfToken(body.csrfToken);return csrfToken;
}
export async function apiRequest(url,options={}){
  const method=(options.method||'GET').toUpperCase();
  const headers={...(options.headers||{})};
  if(options.body!==undefined && !headers['Content-Type'])headers['Content-Type']='application/json';
  if(!['GET','HEAD','OPTIONS'].includes(method))headers['X-CSRF-Token']=csrfToken;
  const response=await fetch(url,{...options,method,headers,credentials:'same-origin'});
  let body={};try{body=await response.json();}catch{}
  if(body.csrfToken)setCsrfToken(body.csrfToken);
  if(!response.ok)throw new Error(body.error||`Request failed (${response.status}).`);
  return body;
}
