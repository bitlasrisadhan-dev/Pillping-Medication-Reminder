import {apiRequest,initializeCsrf} from './api.js';
import {loadState} from './store.js';
import {setTheme,toast} from './ui.js';
const $=selector=>document.querySelector(selector);
export async function initializeAuth(onReady){
 const authScreen=$('#auth-screen'),appShell=$('#app-shell'),form=$('#auth-form'),switchButton=$('#auth-switch');
 const title=$('#auth-title'),caption=$('#auth-caption'),submit=$('#auth-submit'),message=$('#auth-message');let registering=false;
 await initializeCsrf();
 async function enterApp(){
  try{const user=await apiRequest('/auth/me');await loadState();authScreen.classList.add('hidden');appShell.classList.remove('hidden');$('#welcome-name').textContent=user.user.email.split('@')[0];setTheme((await import('./store.js')).getState().theme);await onReady();}
  catch(error){message.textContent=error.message||'Unable to load your account data.';}
 }
 switchButton.addEventListener('click',()=>{
  registering=!registering;title.textContent=registering?'Create your account':'Welcome back';caption.textContent=registering?'Create a secure account for your care dashboard.':'Sign in to access your care dashboard.';submit.textContent=registering?'Create account':'Sign in';switchButton.textContent=registering?'Already have an account? Sign in':'New here? Create an account';$('#auth-password').autocomplete=registering?'new-password':'current-password';message.textContent='';
 });
 form.addEventListener('submit',async event=>{
  event.preventDefault();message.textContent='';submit.disabled=true;
  const payload={email:$('#auth-email').value.trim(),password:$('#auth-password').value};
  try{await apiRequest(registering?'/auth/register':'/auth/login',{method:'POST',body:JSON.stringify(payload)});await enterApp();}
  catch(error){message.textContent=error.message;}
  finally{submit.disabled=false;}
 });
 $('#logout-button').addEventListener('click',async()=>{try{await apiRequest('/auth/logout',{method:'POST',body:'{}'});}catch(error){toast(error.message);}window.location.reload();});
 try{const response=await apiRequest('/auth/me');if(response.user)await enterApp();}catch(_error){}
}
