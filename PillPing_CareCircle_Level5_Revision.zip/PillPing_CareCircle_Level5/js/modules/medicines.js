import {getState,saveState} from './store.js';
import {renderAll,toast} from './ui.js';
const $=selector=>document.querySelector(selector);
const $$=selector=>[...document.querySelectorAll(selector)];
export function addTimeRow(value='12:00'){
 const row=document.createElement('div');row.className='time-row';row.innerHTML=`<input type="time" name="times" value="${value}" required><button class="remove-time" type="button" aria-label="Remove time">×</button>`;
 row.querySelector('button').addEventListener('click',()=>{row.remove();updateRemoveButtons();});$('#time-inputs').append(row);updateRemoveButtons();
}
export function updateRemoveButtons(){const rows=$$('.time-row');rows.forEach(row=>row.querySelector('button').disabled=rows.length===1);}
export async function addMedicine(event){
 event.preventDefault();const form=event.currentTarget,values=new FormData(form),times=[...values.getAll('times')].filter(Boolean);
 const name=String(values.get('name')||'').trim(),dose=String(values.get('dose')||'').trim(),instructions=String(values.get('instructions')||'').trim();
 $('#form-message').textContent='';
 if(name.length<2||name.length>80){$('#form-message').textContent='Medicine name must be 2–80 characters.';return;}
 if(!dose||dose.length>60){$('#form-message').textContent='Enter a valid dosage or instruction.';return;}
 if(!times.length||times.length>4||new Set(times).size!==times.length){$('#form-message').textContent='Choose 1–4 different reminder times.';return;}
 const state=getState();state.medicines.push({id:`med-${crypto.randomUUID()}`,name,dose,instructions,times:times.sort(),states:{}});
 try{await saveState();form.reset();$('#time-inputs').innerHTML='';addTimeRow('08:00');renderAll();$('#form-message').textContent='Medicine added to your schedule.';toast('Medicine added.');}
 catch(error){state.medicines.pop();$('#form-message').textContent=error.message;}
}
export async function markTaken(medicineId,time){
 const state=getState(),medicine=state.medicines.find(item=>String(item.id)===String(medicineId));if(!medicine)return;
 const old=medicine.states?.[time];medicine.states=medicine.states||{};medicine.states[time]='taken';
 try{await saveState();renderAll();toast(`${medicine.name} marked as taken.`);}
 catch(error){medicine.states[time]=old||'pending';renderAll();toast(error.message);}
}
