import {getState} from './store.js';
import {localDate} from './date-time.js';
const $=selector=>document.querySelector(selector);
function getLastSevenDays(){
 const data=getState(),days=[];const today=new Date();
 for(let i=6;i>=0;i--){const d=new Date(today);d.setDate(today.getDate()-i);const key=localDate(d);let item=data.history.find(h=>h.date===key);
  if(key===data.day){const doses=data.medicines.flatMap(m=>m.times.map(time=>m.states?.[time]||'pending'));item={date:key,total:doses.length,taken:doses.filter(x=>x==='taken').length,missed:doses.filter(x=>x==='missed').length};}
  days.push(item||{date:key,total:0,taken:0,missed:0});
 }return days;
}
export function renderWeeklyReport(){
 const days=getLastSevenDays(),total=days.reduce((a,d)=>a+d.total,0),taken=days.reduce((a,d)=>a+d.taken,0),missed=days.reduce((a,d)=>a+d.missed,0),percent=total?Math.round(taken/total*100):0;
 $('#weekly-percent').textContent=`${percent}%`;
 $('#weekly-caption').textContent=total?`${taken} of ${total} scheduled doses confirmed`:'No doses recorded in this period';
 $('#weekly-bars').innerHTML=days.map(d=>{const rate=d.total?Math.round(d.taken/d.total*100):0;const label=new Date(`${d.date}T12:00:00`).toLocaleDateString(undefined,{weekday:'short'});return `<div class="week-bar" title="${d.date}: ${d.taken}/${d.total} taken"><b>${d.total?rate+'%':'—'}</b><div class="week-bar-fill" style="height:${Math.max(d.total?4:2,rate)}%"></div><small>${label}</small></div>`;}).join('');
 $('#weekly-insight').textContent=total?`You confirmed ${taken} of ${total} scheduled doses in the last seven days. ${missed} dose(s) were marked missed. This is an adherence record, not medical advice.`:'Add medicines and record doses to build your seven-day report.';
}
export function exportReport(){
 const data=getState(),rows=[['Date','Medicine','Dosage','Scheduled time','Status']];
 for(const day of getLastSevenDays()){
  if(day.date===data.day){data.medicines.forEach(m=>m.times.forEach(t=>rows.push([day.date,m.name,m.dose,t,m.states?.[t]||'pending'])));}
  else if(day.total)rows.push([day.date,'Daily summary',`${day.taken} taken / ${day.total} scheduled`,'',`${day.missed} missed`]);
 }
 const csv=rows.map(row=>row.map(value=>`"${String(value??'').replace(/"/g,'""')}"`).join(',')).join('\r\n');
 const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='pillping-adherence-report.csv';a.click();URL.revokeObjectURL(url);
}
export function printReport(){window.print();}
