import {apiRequest} from './api.js';
import {localDate,addDays} from './date-time.js';
let state={medicines:[],alerts:[],history:[],notified:[],day:localDate(),theme:'dark',careInsights:null};
export const getState=()=>state;
export function setState(next){state={medicines:[],alerts:[],history:[],notified:[],day:localDate(),theme:'dark',...next};}
export async function loadState(){setState(await apiRequest('/api/data'));return state;}
export async function saveState(){return apiRequest('/api/data',{method:'PUT',body:JSON.stringify(state)});}
export function archiveCurrentDay(){
 const doses=state.medicines.flatMap(m=>(m.times||[]).map(time=>({medicine:m,time,status:m.states?.[time]||'pending'})));
 const total=doses.length,taken=doses.filter(d=>d.status==='taken').length,missed=doses.filter(d=>d.status==='missed').length;
 if(total&&!state.history.some(row=>row.date===state.day))state.history.push({date:state.day,total,taken,missed});
 state.history=state.history.slice(-90);
}
export function advanceToNextDay(){archiveCurrentDay();state.day=addDays(state.day,1);state.alerts=[];state.notified=[];state.medicines.forEach(m=>m.states={});}
