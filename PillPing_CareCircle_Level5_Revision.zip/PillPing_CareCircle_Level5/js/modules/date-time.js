export function localDate(date=new Date()){
 const year=date.getFullYear(),month=String(date.getMonth()+1).padStart(2,'0'),day=String(date.getDate()).padStart(2,'0');
 return `${year}-${month}-${day}`;
}
export function addDays(dateString,days){const date=new Date(`${dateString}T12:00:00`);date.setDate(date.getDate()+days);return localDate(date);}
export function displayTime(time){const [hour,minute]=time.split(':').map(Number),suffix=hour>=12?'PM':'AM';return `${String(hour%12||12).padStart(2,'0')}:${String(minute).padStart(2,'0')} ${suffix}`;}
export function escapeHTML(value){return String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));}
export function formatDate(value){return new Date(`${value}T12:00:00`).toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short',year:'numeric'});}
