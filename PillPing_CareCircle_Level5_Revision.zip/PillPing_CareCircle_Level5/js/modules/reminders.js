import {apiRequest} from './api.js';
import {loadState} from './store.js';
import {renderAll,toast} from './ui.js';
import {getState} from './store.js';
const $=selector=>document.querySelector(selector);
let reminderTimer=null;
export async function checkMissedDoses(manual=false){
 try{
  const result=await apiRequest('/api/reminders/check',{method:'POST',body:'{}'});
  await loadState();renderAll();
  if(manual)toast(result.newlyMissed?`${result.newlyMissed} missed-dose alert(s) created.`:'No new missed doses found.');
 }catch(error){if(manual)toast(error.message);}
}
function notifyDueDoses(){
 const data=getState(),now=new Date(),today=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
 for(const medicine of data.medicines){
  for(const time of medicine.times){
   const [hour,minute]=time.split(':').map(Number),due=new Date();due.setHours(hour,minute,0,0);
   const key=`${medicine.id}_${time}_${today}`;
   if(now>=due&&now-due<60000&&(medicine.states?.[time]||'pending')==='pending'&&!data.notified.includes(key)){
    data.notified.push(key);
    if('Notification' in window&&Notification.permission==='granted')new Notification('PillPing medicine reminder',{body:`Time for ${medicine.name} — ${medicine.dose}.`});
    else toast(`Reminder: ${medicine.name} is scheduled now.`);
   }
  }
 }
}
export function startReminderChecks(){
 if(reminderTimer)clearInterval(reminderTimer);
 notifyDueDoses();
 reminderTimer=setInterval(()=>{notifyDueDoses();checkMissedDoses(false);},30000);
}
export async function requestNotificationPermission(){
 if(!('Notification' in window)){$('#notification-status').textContent='This browser does not support notifications.';return;}
 const permission=await Notification.requestPermission();
 $('#notification-status').textContent=permission==='granted'?'Browser reminders enabled while this page is open.':'Notification permission was not granted.';
}
