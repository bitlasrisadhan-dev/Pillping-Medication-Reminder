import {getState} from './store.js';
import {displayTime,escapeHTML,formatDate,localDate} from './date-time.js';
import {renderWeeklyReport} from './reports.js';
const $=selector=>document.querySelector(selector);
const $$=selector=>[...document.querySelectorAll(selector)];
export function toast(message){const element=$('#toast');element.textContent=message;element.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>element.classList.remove('show'),2800);}
export function setTheme(theme){document.body.classList.toggle('light',theme==='light');$('#theme-toggle').innerHTML=theme==='dark'?'☼ <span>Light mode</span>':'☾ <span>Dark mode</span>';}
function doseStatus(medicine,time){return medicine.states?.[time]||'pending';}
function getStats(){const doses=getState().medicines.flatMap(m=>m.times.map(time=>doseStatus(m,time)));return {total:doses.length,taken:doses.filter(s=>s==='taken').length,missed:doses.filter(s=>s==='missed').length,pending:doses.filter(s=>s==='pending').length};}
export function renderPatient(){
 const data=getState(),stats=getStats(),percentage=stats.total?Math.round(stats.taken/stats.total*100):0;
 $('#stat-total').textContent=stats.total;$('#stat-taken').textContent=stats.taken;$('#stat-pending').textContent=stats.pending;$('#stat-missed').textContent=stats.missed;
 $('#progress-text').textContent=`${percentage}% completed`;$('#progress-fill').style.width=`${percentage}%`;
 $('#medicine-list').innerHTML=data.medicines.map(m=>{
  const statuses=m.times.map(t=>doseStatus(m,t));const overall=statuses.every(s=>s==='taken')?'taken':statuses.some(s=>s==='missed')?'missed':'pending';
  return `<article class="medicine-card"><div class="pill-icon">✚</div><div class="medicine-info"><h3>${escapeHTML(m.name)}</h3><p>${escapeHTML(m.dose)} · ${escapeHTML(m.instructions||'Follow the prescribed instructions')}</p><div class="time-chips">${m.times.map(t=>`<span class="time-chip">${displayTime(t)}</span>`).join('')}</div></div><div class="dose-actions"><span class="status-tag status-${overall}">${overall==='taken'?'Completed':overall==='missed'?'Missed':'Scheduled'}</span>${m.times.map(t=>`<button class="taken-button" data-take="${escapeHTML(m.id)}" data-time="${t}" ${doseStatus(m,t)==='taken'?'disabled':''}>${doseStatus(m,t)==='taken'?'✓ Taken':'Mark taken · '+displayTime(t)}</button>`).join('')}</div></article>`;
 }).join('');
 $('#empty-state').classList.toggle('hidden',data.medicines.length>0);
 $('#today-label').textContent=formatDate(data.day);$('#day-date').textContent=new Date(`${data.day}T12:00:00`).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'});$('#day-number').textContent=data.day.slice(-2);
 renderWeeklyReport();
}
export function renderCaregiver(){
 const data=getState(),stats=getStats(),insight=data.careInsights||{score:0,level:'routine',reasons:['No recent pattern data'],missedLast7Days:0,adherencePercent:0};
 $('#care-total').textContent=stats.total;$('#care-taken').textContent=stats.taken;$('#care-missed').textContent=stats.missed;
 $('#alert-count').textContent=`${data.alerts.length} alert${data.alerts.length===1?'':'s'}`;$('#no-alerts').classList.toggle('hidden',data.alerts.length>0);
 $('#alert-list').innerHTML=data.alerts.map(a=>`<div class="alert-item"><div><strong>${escapeHTML(a.medicine)} · ${displayTime(a.time)}</strong><small>${escapeHTML(a.message)}</small><span class="priority-badge priority-${escapeHTML(a.priority_level||'routine')}">${escapeHTML(a.priority_level||'routine')} · ${Number(a.priority_score||0)}/100</span></div><button data-resolve="${a.id}">Acknowledge</button></div>`).join('');
 $('#care-status-list').innerHTML=data.medicines.map(m=>{
  const statuses=m.times.map(t=>doseStatus(m,t));const status=statuses.some(s=>s==='missed')?'missed':statuses.every(s=>s==='taken')?'taken':'pending';
  return `<div class="care-status-item"><div><strong>${escapeHTML(m.name)}</strong><small>${escapeHTML(m.dose)} · ${m.times.map(displayTime).join(', ')}</small></div><span class="status-tag status-${status}">${status==='taken'?'Done':status==='missed'?'Missed':'Pending'}</span></div>`;
 }).join('');
 $('#care-priority-score').textContent=`${insight.score}/100`;
 $('#care-priority-label').textContent=insight.level==='priority'?'Priority follow-up':insight.level==='attention'?'Attention advised':'Routine follow-up';
 $('#care-priority-reasons').textContent=insight.reasons.join(' · ');
 $('#care-adherence').textContent=`${insight.adherencePercent}%`;
}
export function renderAll(){renderPatient();renderCaregiver();}
export const selectAll=$$;
