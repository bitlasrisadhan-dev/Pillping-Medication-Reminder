function createRateLimiter({windowMs=15*60*1000,max=8}={}) {
  const buckets=new Map();
  return (req,res,next)=>{
    const key=req.ip || req.socket.remoteAddress || 'unknown';
    const now=Date.now(); let entry=buckets.get(key);
    if(!entry || now-entry.startedAt>windowMs){entry={startedAt:now,count:0};buckets.set(key,entry);}
    entry.count++;
    if(entry.count>max){res.setHeader('Retry-After',Math.ceil((windowMs-(now-entry.startedAt))/1000));return res.status(429).json({error:'Too many attempts. Wait before trying again.'});}
    if(buckets.size>10000){for(const [k,v] of buckets)if(now-v.startedAt>windowMs)buckets.delete(k);}
    next();
  };
}
module.exports={createRateLimiter};
