const crypto = require('crypto');
function safeEqual(a,b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const left=Buffer.from(a), right=Buffer.from(b);
  return left.length===right.length && crypto.timingSafeEqual(left,right);
}
function csrfProtection(req,res,next) {
  if (!['POST','PUT','PATCH','DELETE'].includes(req.method)) return next();
  const expected=req.session && req.session.csrfToken;
  const supplied=req.get('X-CSRF-Token');
  if (!safeEqual(expected,supplied)) return res.status(403).json({error:'Security token is missing or expired. Refresh the page and try again.'});
  const origin=req.get('Origin');
  if (origin) {
    try {
      const url=new URL(origin);
      if (url.host !== req.get('host')) return res.status(403).json({error:'Request origin was not accepted.'});
    } catch { return res.status(403).json({error:'Request origin is invalid.'}); }
  }
  next();
}
module.exports={csrfProtection};
