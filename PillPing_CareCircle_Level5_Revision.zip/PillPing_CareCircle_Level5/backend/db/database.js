const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const { createSchema } = require('./schema');

function openDatabase(dbPath) {
  const location = dbPath || process.env.PILLPING_DB || path.join(__dirname, '..', '..', 'data', 'pillping.sqlite');
  if (location !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(location)), { recursive: true });
  const db = new Database(location);
  createSchema(db);
  return db;
}

function hasTable(db, tableName) {
  return Boolean(db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(tableName));
}

function migrateLegacyUserData(db) {
  if (!hasTable(db, 'user_data')) return { migrated: 0, skipped: 0 };
  const done = db.prepare("SELECT 1 FROM schema_migrations WHERE migration_key='legacy_user_data_to_relational_v1'").get();
  if (done) return { migrated: 0, skipped: 0 };
  const rows = db.prepare('SELECT user_id,data_json FROM user_data').all();
  const insertMedicine = db.prepare(`INSERT OR IGNORE INTO medicines(owner_id,client_key,name,dosage,instructions,start_date)
    VALUES(?,?,?,?,?,?)`);
  const findMedicine = db.prepare('SELECT id FROM medicines WHERE owner_id=? AND client_key=?');
  const insertTime = db.prepare('INSERT OR IGNORE INTO medicine_times(medicine_id,scheduled_time) VALUES(?,?)');
  const insertDose = db.prepare(`INSERT OR IGNORE INTO dose_records(owner_id,medicine_id,dose_date,scheduled_time,status,confirmed_at,missed_at)
    VALUES(?,?,?,?,?,?,?)`);
  const insertHistory = db.prepare(`INSERT OR IGNORE INTO daily_summaries(owner_id,summary_date,scheduled_count,taken_count,missed_count)
    VALUES(?,?,?,?,?)`);
  const insertNotification = db.prepare('INSERT OR IGNORE INTO notification_log(owner_id,notification_key) VALUES(?,?)');
  const insertPreference = db.prepare(`INSERT INTO user_preferences(user_id,theme,current_day) VALUES(?,?,?)
    ON CONFLICT(user_id) DO UPDATE SET theme=excluded.theme,current_day=excluded.current_day`);
  let migrated = 0, skipped = 0;
  const tx = db.transaction(() => {
    for (const row of rows) {
      let state;
      try { state = JSON.parse(row.data_json); } catch { skipped++; continue; }
      if (!state || !Array.isArray(state.medicines)) { skipped++; continue; }
      const day = /^\d{4}-\d{2}-\d{2}$/.test(state.day || '') ? state.day : new Date().toLocaleDateString('en-CA');
      insertPreference.run(row.user_id, state.theme === 'light' ? 'light' : 'dark', day);
      for (const med of state.medicines) {
        if (!med || typeof med.name !== 'string' || typeof med.dose !== 'string' || !Array.isArray(med.times)) continue;
        const clientKey = String(med.id ?? `${med.name}-${med.times.join('-')}`);
        insertMedicine.run(row.user_id, clientKey, med.name.slice(0,80), med.dose.slice(0,60), String(med.instructions || '').slice(0,240), day);
        const found = findMedicine.get(row.user_id, clientKey);
        if (!found) continue;
        for (const time of med.times) {
          if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) continue;
          insertTime.run(found.id, time);
          const status = ['taken','missed','skipped','pending'].includes(med.states?.[time]) ? med.states[time] : 'pending';
          insertDose.run(row.user_id, found.id, day, time, status, status === 'taken' ? new Date().toISOString() : null, status === 'missed' ? new Date().toISOString() : null);
        }
      }
      for (const h of (Array.isArray(state.history) ? state.history : [])) {
        if (/^\d{4}-\d{2}-\d{2}$/.test(h.date || '')) insertHistory.run(row.user_id,h.date,Number(h.total)||0,Number(h.taken)||0,Number(h.missed)||0);
      }
      for (const key of (Array.isArray(state.notified) ? state.notified : [])) if (typeof key === 'string' && key.length < 200) insertNotification.run(row.user_id,key);
      migrated++;
    }
    db.prepare("INSERT OR REPLACE INTO schema_migrations(migration_key) VALUES('legacy_user_data_to_relational_v1')").run();
  });
  tx();
  // Preserve the old table for audit/recovery; all current reads and writes use the normalized tables.
  return { migrated, skipped };
}
module.exports = { openDatabase, migrateLegacyUserData, hasTable };
