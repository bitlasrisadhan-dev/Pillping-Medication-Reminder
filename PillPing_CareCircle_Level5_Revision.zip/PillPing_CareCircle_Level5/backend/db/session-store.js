const session = require('express-session');

class SQLiteSessionStore extends session.Store {
  constructor(db) {
    super();
    this.db = db;
    this.getStatement = db.prepare('SELECT session_json, expires_at FROM sessions WHERE sid=?');
    this.setStatement = db.prepare(`INSERT INTO sessions(sid,session_json,expires_at) VALUES(?,?,?)
      ON CONFLICT(sid) DO UPDATE SET session_json=excluded.session_json, expires_at=excluded.expires_at`);
    this.destroyStatement = db.prepare('DELETE FROM sessions WHERE sid=?');
    this.touchStatement = db.prepare('UPDATE sessions SET expires_at=? WHERE sid=?');
  }
  get(sid, callback) {
    try {
      const row = this.getStatement.get(sid);
      if (!row) return callback(null, null);
      if (row.expires_at <= Date.now()) {
        this.destroyStatement.run(sid);
        return callback(null, null);
      }
      callback(null, JSON.parse(row.session_json));
    } catch (error) { callback(error); }
  }
  set(sid, sessionData, callback = () => {}) {
    try {
      const expiresAt = sessionData.cookie && sessionData.cookie.expires
        ? new Date(sessionData.cookie.expires).getTime()
        : Date.now() + Number(sessionData.cookie?.originalMaxAge || 8 * 60 * 60 * 1000);
      this.setStatement.run(sid, JSON.stringify(sessionData), expiresAt);
      callback(null);
    } catch (error) { callback(error); }
  }
  destroy(sid, callback = () => {}) {
    try { this.destroyStatement.run(sid); callback(null); }
    catch (error) { callback(error); }
  }
  touch(sid, sessionData, callback = () => {}) {
    try {
      const expiresAt = sessionData.cookie && sessionData.cookie.expires
        ? new Date(sessionData.cookie.expires).getTime()
        : Date.now() + Number(sessionData.cookie?.originalMaxAge || 8 * 60 * 60 * 1000);
      this.touchStatement.run(expiresAt, sid);
      callback(null);
    } catch (error) { callback(error); }
  }
  cleanupExpired() {
    this.db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now());
  }
}
module.exports = { SQLiteSessionStore };
