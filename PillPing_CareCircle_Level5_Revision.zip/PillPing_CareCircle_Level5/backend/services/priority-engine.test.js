const test=require('node:test');
const assert=require('node:assert/strict');
const {calculateFollowUpPriority}=require('./priority-engine');

test('priority engine returns routine when there are no missed doses',()=>{
 const result=calculateFollowUpPriority();assert.equal(result.score,0);assert.equal(result.level,'routine');
});
test('priority score increases as missed count and overdue time increase',()=>{
 const low=calculateFollowUpPriority({missedLast7Days:1,consecutiveMisses:1,overdueMinutes:20});
 const high=calculateFollowUpPriority({missedLast7Days:5,consecutiveMisses:4,overdueMinutes:180});
 assert.ok(high.score>low.score);assert.equal(high.level,'priority');
});
test('priority score is bounded from 0 to 100',()=>{
 const result=calculateFollowUpPriority({missedLast7Days:100,consecutiveMisses:100,overdueMinutes:9999});
 assert.equal(result.score,100);
});
