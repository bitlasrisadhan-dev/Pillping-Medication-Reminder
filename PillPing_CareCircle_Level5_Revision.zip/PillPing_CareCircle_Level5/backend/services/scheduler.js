const { ensureDailyDoseRows, calculateSummary } = require('./repository');
const { localDate } = require('./date-time');
const { calculateFollowUpPriority } = require('./priority-engine');

function sweepMissedDoses(db, options = {}) {
  const now = options.now || new Date();
  const graceMinutes = Number.isInteger(options.graceMinutes) ? options.graceMinutes : 15;
  const today = localDate(now);
  const owners = db.prepare('SELECT id FROM users').all();
  const createAlert = db.prepare(`INSERT OR IGNORE INTO alerts(owner_id,dose_record_id,message)
    VALUES(?,?,?)`);
  const markMissed = db.prepare(`UPDATE dose_records SET status='missed',missed_at=COALESCE(missed_at,?),updated_at=CURRENT_TIMESTAMP
    WHERE id=? AND status='pending'`);
  const pendingQuery = db.prepare(`SELECT d.id,d.owner_id,d.medicine_id,d.dose_date,d.scheduled_time,m.name AS medicine_name
    FROM dose_records d JOIN medicines m ON m.id=d.medicine_id
    WHERE d.dose_date=? AND d.status='pending' AND d.scheduled_time<=?`);
  let newlyMissed = 0;
  const tx = db.transaction(() => {
    for (const owner of owners) ensureDailyDoseRows(db,owner.id,today);
    const currentTime = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    for (const dose of pendingQuery.all(today,currentTime)) {
      const scheduledAt = new Date(`${dose.dose_date}T${dose.scheduled_time}:00`);
      const overdueMinutes = Math.floor((now.getTime() - scheduledAt.getTime()) / 60000);
      if (overdueMinutes <= graceMinutes) continue;
      if (markMissed.run(now.toISOString(),dose.id).changes) {
        createAlert.run(dose.owner_id,dose.id,`${dose.medicine_name} was not confirmed within ${graceMinutes} minutes of its scheduled time.`);
        newlyMissed++;
      }
    }
    for (const owner of owners) {
      calculateSummary(db,owner.id,today);
      const missed = db.prepare(`SELECT COUNT(*) AS count FROM dose_records WHERE owner_id=? AND status='missed' AND dose_date>=date(?,'-6 day')`).get(owner.id,today).count;
      const latest = db.prepare(`SELECT status FROM dose_records WHERE owner_id=? ORDER BY dose_date DESC,scheduled_time DESC LIMIT 10`).all(owner.id);
      let streak=0; for(const row of latest){if(row.status==='missed')streak++;else if(row.status==='taken')break;}
      const openAlerts = db.prepare(`SELECT a.id,d.dose_date,d.scheduled_time FROM alerts a JOIN dose_records d ON d.id=a.dose_record_id
        WHERE a.owner_id=? AND a.status='open'`).all(owner.id);
      for (const alert of openAlerts) {
        const due = new Date(`${alert.dose_date}T${alert.scheduled_time}:00`);
        const overdue = Math.max(0,Math.floor((now-due)/60000));
        const priority = calculateFollowUpPriority({missedLast7Days:missed,consecutiveMisses:streak,overdueMinutes:overdue});
        db.prepare('UPDATE alerts SET priority_score=?,priority_level=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(priority.score,priority.level,alert.id);
      }
    }
  });
  tx();
  return { date: today, usersChecked: owners.length, newlyMissed };
}

function startScheduler(db, options = {}) {
  const intervalMs = Math.max(15000, Number(options.intervalMs || 60000));
  const run = () => {
    try { const result=sweepMissedDoses(db,{graceMinutes:options.graceMinutes}); if(result.newlyMissed) console.log(`PillPing scheduler: ${result.newlyMissed} missed dose alert(s) created.`); }
    catch (error) { console.error('PillPing scheduler error:',error.message); }
  };
  run();
  const timer=setInterval(run,intervalMs);
  if (timer.unref) timer.unref();
  const cleanup=setInterval(()=>{try{db.prepare('DELETE FROM sessions WHERE expires_at<=?').run(Date.now());}catch(error){console.error(error.message);}},60*60*1000);
  if (cleanup.unref) cleanup.unref();
  return { stop:()=>{clearInterval(timer);clearInterval(cleanup);} };
}
module.exports={sweepMissedDoses,startScheduler};
