const { localDate } = require('./date-time');
const { calculateFollowUpPriority } = require('./priority-engine');

function ensureDailyDoseRows(db, ownerId, date) {
  const medicines = db.prepare(`SELECT m.id, mt.scheduled_time FROM medicines m
    JOIN medicine_times mt ON mt.medicine_id=m.id
    WHERE m.owner_id=? AND m.is_active=1 AND m.start_date<=?`).all(ownerId,date);
  const add = db.prepare(`INSERT OR IGNORE INTO dose_records(owner_id,medicine_id,dose_date,scheduled_time,status)
    VALUES(?,?,?,?,'pending')`);
  const tx = db.transaction(() => medicines.forEach(m => add.run(ownerId,m.id,date,m.scheduled_time)));
  tx();
}

function calculateSummary(db, ownerId, date) {
  const row = db.prepare(`SELECT COUNT(*) AS total,
    SUM(CASE WHEN status='taken' THEN 1 ELSE 0 END) AS taken,
    SUM(CASE WHEN status='missed' THEN 1 ELSE 0 END) AS missed
    FROM dose_records WHERE owner_id=? AND dose_date=?`).get(ownerId,date);
  db.prepare(`INSERT INTO daily_summaries(owner_id,summary_date,scheduled_count,taken_count,missed_count,updated_at)
    VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(owner_id,summary_date) DO UPDATE SET scheduled_count=excluded.scheduled_count,
    taken_count=excluded.taken_count,missed_count=excluded.missed_count,updated_at=CURRENT_TIMESTAMP`)
    .run(ownerId,date,row.total || 0,row.taken || 0,row.missed || 0);
  return { date, total: row.total || 0, taken: row.taken || 0, missed: row.missed || 0 };
}

function getFollowUpInsight(db, ownerId, now = new Date()) {
  const from = new Date(now); from.setDate(from.getDate() - 6);
  const startDate = localDate(from);
  const missedRows = db.prepare(`SELECT dose_date, scheduled_time FROM dose_records
    WHERE owner_id=? AND status='missed' AND dose_date>=? ORDER BY dose_date DESC, scheduled_time DESC`).all(ownerId,startDate);
  let consecutive = 0;
  const latest = db.prepare(`SELECT status,dose_date,scheduled_time FROM dose_records WHERE owner_id=?
    ORDER BY dose_date DESC, scheduled_time DESC LIMIT 20`).all(ownerId);
  for (const row of latest) { if (row.status === 'missed') consecutive++; else if (row.status === 'taken') break; }
  let overdueMinutes = 0;
  if (missedRows.length) {
    const latestMiss = missedRows[0];
    const scheduled = new Date(`${latestMiss.dose_date}T${latestMiss.scheduled_time}:00`);
    overdueMinutes = Math.max(0, Math.floor((now - scheduled) / 60000));
  }
  const priority = calculateFollowUpPriority({ missedLast7Days: missedRows.length, consecutiveMisses: consecutive, overdueMinutes });
  const totals = db.prepare(`SELECT COUNT(*) AS total, SUM(CASE WHEN status='taken' THEN 1 ELSE 0 END) AS taken
    FROM dose_records WHERE owner_id=? AND dose_date>=?`).get(ownerId,startDate);
  const adherence = totals.total ? Math.round((totals.taken / totals.total) * 100) : 0;
  return { ...priority, missedLast7Days: missedRows.length, consecutiveMisses: consecutive, adherencePercent: adherence };
}

function getState(db, ownerId, requestedDate) {
  const today = requestedDate || localDate();
  let prefs = db.prepare('SELECT theme,current_day FROM user_preferences WHERE user_id=?').get(ownerId);
  if (!prefs) {
    db.prepare('INSERT INTO user_preferences(user_id,theme,current_day) VALUES(?,?,?)').run(ownerId,'dark',today);
    prefs = { theme: 'dark', current_day: today };
  }
  const date = requestedDate || prefs.current_day || today;
  ensureDailyDoseRows(db,ownerId,date);
  const meds = db.prepare('SELECT * FROM medicines WHERE owner_id=? AND is_active=1 ORDER BY name,id').all(ownerId);
  const timesStmt = db.prepare('SELECT scheduled_time FROM medicine_times WHERE medicine_id=? ORDER BY scheduled_time');
  const statesStmt = db.prepare('SELECT scheduled_time,status FROM dose_records WHERE medicine_id=? AND dose_date=?');
  const medicines = meds.map(m => {
    const times = timesStmt.all(m.id).map(row => row.scheduled_time);
    const states = {};
    statesStmt.all(m.id,date).forEach(row => { states[row.scheduled_time] = row.status; });
    return { id: m.client_key, name: m.name, dose: m.dosage, instructions: m.instructions, times, states };
  });
  const alerts = db.prepare(`SELECT a.id,a.message,a.priority_score,a.priority_level,a.status,
      d.dose_date AS date,d.scheduled_time AS time,m.client_key AS medicineId,m.name AS medicine
    FROM alerts a JOIN dose_records d ON d.id=a.dose_record_id JOIN medicines m ON m.id=d.medicine_id
    WHERE a.owner_id=? AND a.status IN ('open','acknowledged') ORDER BY a.created_at DESC LIMIT 100`).all(ownerId);
  const history = db.prepare(`SELECT summary_date AS date, scheduled_count AS total, taken_count AS taken, missed_count AS missed
    FROM daily_summaries WHERE owner_id=? ORDER BY summary_date DESC LIMIT 60`).all(ownerId).reverse();
  const notified = db.prepare('SELECT notification_key FROM notification_log WHERE owner_id=? AND notification_key LIKE ?').all(ownerId,`%_${date}`).map(row => row.notification_key);
  const summary = calculateSummary(db,ownerId,date);
  if (!history.some(item => item.date === date)) history.push(summary);
  const careInsights = getFollowUpInsight(db,ownerId);
  return { medicines, alerts, history, notified, day: date, theme: prefs.theme || 'dark', careInsights };
}

function saveState(db, ownerId, state) {
  const date = state.day || localDate();
  const upsertMedicine = db.prepare(`INSERT INTO medicines(owner_id,client_key,name,dosage,instructions,start_date,is_active,updated_at)
    VALUES(?,?,?,?,?,?,1,CURRENT_TIMESTAMP)
    ON CONFLICT(owner_id,client_key) DO UPDATE SET name=excluded.name,dosage=excluded.dosage,
    instructions=excluded.instructions,is_active=1,updated_at=CURRENT_TIMESTAMP`);
  const findMedicine = db.prepare('SELECT id FROM medicines WHERE owner_id=? AND client_key=?');
  const deleteTimes = db.prepare('DELETE FROM medicine_times WHERE medicine_id=?');
  const insertTime = db.prepare('INSERT INTO medicine_times(medicine_id,scheduled_time) VALUES(?,?)');
  const insertDose = db.prepare(`INSERT OR IGNORE INTO dose_records(owner_id,medicine_id,dose_date,scheduled_time,status)
    VALUES(?,?,?,?,'pending')`);
  const markTaken = db.prepare(`UPDATE dose_records SET status='taken',confirmed_at=COALESCE(confirmed_at,CURRENT_TIMESTAMP),updated_at=CURRENT_TIMESTAMP
    WHERE owner_id=? AND medicine_id=? AND dose_date=? AND scheduled_time=? AND status IN ('pending','missed')`);
  const markMissed = db.prepare(`UPDATE dose_records SET status='missed',missed_at=COALESCE(missed_at,CURRENT_TIMESTAMP),updated_at=CURRENT_TIMESTAMP
    WHERE owner_id=? AND medicine_id=? AND dose_date=? AND scheduled_time=? AND status='pending'`);
  const upsertHistory = db.prepare(`INSERT INTO daily_summaries(owner_id,summary_date,scheduled_count,taken_count,missed_count)
    VALUES(?,?,?,?,?) ON CONFLICT(owner_id,summary_date) DO UPDATE SET
    scheduled_count=excluded.scheduled_count,taken_count=excluded.taken_count,missed_count=excluded.missed_count,updated_at=CURRENT_TIMESTAMP`);
  const insertNotification = db.prepare('INSERT OR IGNORE INTO notification_log(owner_id,notification_key) VALUES(?,?)');
  const savePreferences = db.prepare(`INSERT INTO user_preferences(user_id,theme,current_day) VALUES(?,?,?)
    ON CONFLICT(user_id) DO UPDATE SET theme=excluded.theme,current_day=excluded.current_day,updated_at=CURRENT_TIMESTAMP`);
  const deactivateMissing = db.prepare('UPDATE medicines SET is_active=0,updated_at=CURRENT_TIMESTAMP WHERE owner_id=?');
  const tx = db.transaction(() => {
    savePreferences.run(ownerId,state.theme === 'light' ? 'light' : 'dark',date);
    deactivateMissing.run(ownerId);
    for (const med of state.medicines) {
      const key = String(med.id);
      upsertMedicine.run(ownerId,key,med.name.trim(),med.dose.trim(),String(med.instructions || '').trim(),date);
      const dbMed = findMedicine.get(ownerId,key);
      deleteTimes.run(dbMed.id);
      for (const time of med.times) {
        insertTime.run(dbMed.id,time);
        insertDose.run(ownerId,dbMed.id,date,time);
        const status = med.states?.[time];
        if (status === 'taken') markTaken.run(ownerId,dbMed.id,date,time);
        else if (status === 'missed') markMissed.run(ownerId,dbMed.id,date,time);
      }
    }
    for (const h of state.history || []) upsertHistory.run(ownerId,h.date,h.total,h.taken,h.missed);
    for (const key of state.notified || []) insertNotification.run(ownerId,key);
  });
  tx();
  calculateSummary(db,ownerId,date);
  return { savedAt: new Date().toISOString() };
}

function acknowledgeAlert(db, ownerId, alertId) {
  return db.prepare(`UPDATE alerts SET status='acknowledged',updated_at=CURRENT_TIMESTAMP
    WHERE id=? AND owner_id=? AND status='open'`).run(alertId,ownerId).changes;
}
module.exports = { ensureDailyDoseRows, calculateSummary, getFollowUpInsight, getState, saveState, acknowledgeAlert };
