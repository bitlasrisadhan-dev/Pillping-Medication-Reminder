const test=require('node:test');
const assert=require('node:assert/strict');
const {validateAppState,validateEmail,validatePassword}=require('./validation');
const valid={medicines:[{id:'m-1',name:'Example tablet',dose:'1 tablet',instructions:'After food',times:['08:00'],states:{'08:00':'pending'}}],history:[],notified:[],alerts:[],day:'2026-11-20',theme:'dark'};
test('valid account values are accepted',()=>{assert.equal(validateEmail('user@example.com'),true);assert.equal(validatePassword('secure123'),true);});
test('rejects duplicate or malformed medicine times',()=>{const data=structuredClone(valid);data.medicines[0].times=['08:00','08:00'];assert.match(validateAppState(data),/unique valid/);});
test('rejects unknown dose states',()=>{const data=structuredClone(valid);data.medicines[0].states['08:00']='maybe';assert.match(validateAppState(data),/invalid time or status/);});
test('accepts valid nested schedule state',()=>{assert.equal(validateAppState(valid),null);});
