function pad(value) { return String(value).padStart(2, '0'); }
function localDate(date = new Date()) {
  return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`;
}
function localTime(date = new Date()) {
  return `${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function isDateString(value) { return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value); }
function isTimeString(value) { return typeof value === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value); }
module.exports = { localDate, localTime, isDateString, isTimeString };
