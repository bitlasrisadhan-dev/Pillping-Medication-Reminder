const { isDateString, isTimeString } = require('./date-time');
function validateEmail(email) {
  return typeof email === 'string' && email.length <= 160 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function validatePassword(password) {
  return typeof password === 'string' && password.length >= 8 && password.length <= 100;
}
function validateAppState(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return 'Request body must be an object.';
  if (!Array.isArray(value.medicines) || value.medicines.length > 100) return 'Medicine list is invalid or exceeds 100 items.';
  if (!Array.isArray(value.history) || value.history.length > 90) return 'History list is invalid or exceeds 90 records.';
  if (!Array.isArray(value.notified) || value.notified.length > 500) return 'Notification list is invalid or exceeds 500 keys.';
  if (value.alerts !== undefined && (!Array.isArray(value.alerts) || value.alerts.length > 500)) return 'Alert list is invalid.';
  if (value.theme !== undefined && !['dark','light'].includes(value.theme)) return 'Theme value is invalid.';
  if (value.day !== undefined && !isDateString(value.day)) return 'Date must use YYYY-MM-DD format.';
  const clientKeys = new Set();
  for (const med of value.medicines) {
    if (!med || (typeof med.id !== 'string' && typeof med.id !== 'number')) return 'Each medicine needs an identifier.';
    const key = String(med.id);
    if (!key || key.length > 80 || clientKeys.has(key)) return 'Medicine identifiers must be unique.';
    clientKeys.add(key);
    if (typeof med.name !== 'string' || med.name.trim().length < 2 || med.name.length > 80) return 'Medicine name must contain 2–80 characters.';
    if (typeof med.dose !== 'string' || med.dose.trim().length < 1 || med.dose.length > 60) return 'Dosage/instructions must contain 1–60 characters.';
    if (typeof (med.instructions || '') !== 'string' || (med.instructions || '').length > 240) return 'Medicine notes must be 240 characters or fewer.';
    if (!Array.isArray(med.times) || med.times.length < 1 || med.times.length > 4) return 'Each medicine must have 1–4 reminder times.';
    if (new Set(med.times).size !== med.times.length || med.times.some(time => !isTimeString(time))) return 'Reminder times must be unique valid HH:MM values.';
    if (med.states !== undefined && (!med.states || typeof med.states !== 'object' || Array.isArray(med.states))) return 'Dose state must be an object.';
    for (const [time,status] of Object.entries(med.states || {})) {
      if (!med.times.includes(time) || !['pending','taken','missed','skipped'].includes(status)) return 'Dose state contains an invalid time or status.';
    }
  }
  for (const row of value.history) {
    if (!row || !isDateString(row.date) || ![row.total,row.taken,row.missed].every(n => Number.isInteger(n) && n >= 0) || row.taken > row.total || row.missed > row.total) return 'A history record is invalid.';
  }
  if (value.notified.some(key => typeof key !== 'string' || key.length > 200)) return 'A notification key is invalid.';
  return null;
}
module.exports = { validateEmail, validatePassword, validateAppState };
