// Operational follow-up score: it prioritises records for caregiver review only.
// It is not a medical risk score and must not be used to change medication.
function calculateFollowUpPriority({ missedLast7Days = 0, consecutiveMisses = 0, overdueMinutes = 0 } = {}) {
  const missed = Math.max(0, Math.min(10, Number(missedLast7Days) || 0));
  const streak = Math.max(0, Math.min(6, Number(consecutiveMisses) || 0));
  const overdue = Math.max(0, Math.min(360, Number(overdueMinutes) || 0));
  const score = Math.min(100, Math.round(missed * 9 + streak * 8 + overdue / 6));
  const level = score >= 60 ? 'priority' : score >= 30 ? 'attention' : 'routine';
  const reasons = [];
  if (missed) reasons.push(`${missed} unconfirmed dose(s) in the last 7 days`);
  if (streak > 1) reasons.push(`${streak} consecutive missed dose(s)`);
  if (overdue >= 30) reasons.push(`latest missed dose is ${overdue} minutes overdue`);
  if (!reasons.length) reasons.push('No recent missed-dose pattern detected');
  return { score, level, reasons };
}
module.exports = { calculateFollowUpPriority };
