const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const crypto = require('crypto');
const { openDatabase, migrateLegacyUserData } = require('./db/database');
const { SQLiteSessionStore } = require('./db/session-store');
const { validateEmail, validatePassword, validateAppState } = require('./services/validation');
const { getState, saveState, acknowledgeAlert } = require('./services/repository');
const { sweepMissedDoses } = require('./services/scheduler');
const { csrfProtection } = require('./middleware/csrf');
const { createRateLimiter } = require('./middleware/rate-limit');

function createApp(options = {}) {
  const app=express();
  const db=openDatabase(options.dbPath);
  const migration=migrateLegacyUserData(db);
  if(migration.migrated) console.log(`PillPing migration: ${migration.migrated} legacy account(s) moved to relational tables.`);
  app.locals.db=db;

  const sessionSecret=options.sessionSecret || process.env.SESSION_SECRET || (process.env.NODE_ENV==='production' ? null : crypto.randomBytes(48).toString('hex'));
  if(!sessionSecret) throw new Error('SESSION_SECRET is required in production. Copy .env.example to .env and set a random secret.');
  if(!options.sessionSecret && !process.env.SESSION_SECRET && process.env.NODE_ENV!=='production') console.warn('PillPing: temporary development session secret in use. Create a .env file for stable sessions.');

  app.disable('x-powered-by');
  app.set('trust proxy', process.env.TRUST_PROXY === '1' ? 1 : false);
  app.use((req,res,next)=>{
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('X-Frame-Options','DENY');
    res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
    next();
  });
  app.use(express.json({limit:'100kb',strict:true}));
  app.use(session({
    name:'pillping.sid',
    store:new SQLiteSessionStore(db),
    secret:sessionSecret,
    resave:false,
    saveUninitialized:false,
    rolling:true,
    cookie:{httpOnly:true,sameSite:'strict',secure:options.secureCookies ?? process.env.NODE_ENV==='production',maxAge:8*60*60*1000,path:'/'}
  }));
  app.use(csrfProtection);

  const loginLimiter=createRateLimiter({windowMs:15*60*1000,max:10});
  const registerLimiter=createRateLimiter({windowMs:60*60*1000,max:5});
  function requireAuth(req,res,next){
    if(!req.session.userId) return res.status(401).json({error:'Please sign in to continue.'});
    const user=db.prepare('SELECT id,email FROM users WHERE id=?').get(req.session.userId);
    if(!user){req.session.destroy(()=>{});return res.status(401).json({error:'Account session is no longer valid.'});}
    req.user=user;next();
  }
  function regenerateSession(req,userId){
    return new Promise((resolve,reject)=>req.session.regenerate(err=>{
      if(err)return reject(err);
      req.session.userId=userId;
      req.session.csrfToken=crypto.randomBytes(32).toString('hex');
      req.session.save(saveError=>saveError?reject(saveError):resolve(req.session.csrfToken));
    }));
  }

  app.get('/auth/csrf',(req,res)=>{
    if(!req.session.csrfToken)req.session.csrfToken=crypto.randomBytes(32).toString('hex');
    res.json({csrfToken:req.session.csrfToken});
  });
  app.post('/auth/register',registerLimiter,async(req,res)=>{
    const email=typeof req.body.email==='string'?req.body.email.trim().toLowerCase():'';
    const password=req.body.password;
    if(!validateEmail(email))return res.status(400).json({error:'Enter a valid email address.'});
    if(!validatePassword(password))return res.status(400).json({error:'Password must contain 8–100 characters.'});
    try{
      const hash=await bcrypt.hash(password,12);
      const create=db.transaction(()=>{
        const result=db.prepare('INSERT INTO users(email,password_hash) VALUES(?,?)').run(email,hash);
        db.prepare("INSERT INTO user_preferences(user_id,theme,current_day) VALUES(?,?,?)").run(result.lastInsertRowid,'dark',new Date().toLocaleDateString('en-CA'));
        db.prepare("INSERT INTO audit_logs(actor_id,action,entity_type,entity_id) VALUES(?,?,?,?)").run(result.lastInsertRowid,'account.registered','user',result.lastInsertRowid);
        return Number(result.lastInsertRowid);
      });
      const userId=create();
      const csrfToken=await regenerateSession(req,userId);
      res.status(201).json({user:{id:userId,email},csrfToken});
    }catch(error){
      if(error.code==='SQLITE_CONSTRAINT_UNIQUE')return res.status(409).json({error:'An account with this email already exists.'});
      console.error('Registration error:',error.message);res.status(500).json({error:'Could not create the account. Please try again.'});
    }
  });
  app.post('/auth/login',loginLimiter,async(req,res)=>{
    const email=typeof req.body.email==='string'?req.body.email.trim().toLowerCase():'';
    const password=req.body.password;
    if(!validateEmail(email)||typeof password!=='string')return res.status(400).json({error:'Enter a valid email and password.'});
    try{
      const user=db.prepare('SELECT id,email,password_hash FROM users WHERE email=?').get(email);
      if(!user||!(await bcrypt.compare(password,user.password_hash)))return res.status(401).json({error:'Email or password is incorrect.'});
      const csrfToken=await regenerateSession(req,user.id);
      db.prepare("INSERT INTO audit_logs(actor_id,action,entity_type,entity_id) VALUES(?,?,?,?)").run(user.id,'account.login','user',user.id);
      res.json({user:{id:user.id,email:user.email},csrfToken});
    }catch(error){console.error('Login error:',error.message);res.status(500).json({error:'Could not sign in. Please try again.'});}
  });
  app.get('/auth/me',requireAuth,(req,res)=>res.json({user:req.user}));
  app.post('/auth/logout',requireAuth,(req,res)=>{
    const userId=req.user.id;
    req.session.destroy(error=>{
      if(error)return res.status(500).json({error:'Could not close the session.'});
      db.prepare("INSERT INTO audit_logs(actor_id,action,entity_type,entity_id) VALUES(?,?,?,?)").run(userId,'account.logout','user',userId);
      res.clearCookie('pillping.sid',{path:'/',sameSite:'strict',secure:options.secureCookies ?? process.env.NODE_ENV==='production'}).json({ok:true});
    });
  });

  app.get('/api/data',requireAuth,(req,res)=>{
    try{res.json(getState(db,req.user.id,req.query.date));}
    catch(error){console.error('Read data error:',error.message);res.status(500).json({error:'Could not load your saved data.'});}
  });
  app.put('/api/data',requireAuth,(req,res)=>{
    const validationError=validateAppState(req.body);
    if(validationError)return res.status(400).json({error:validationError});
    try{
      const result=saveState(db,req.user.id,req.body);
      db.prepare("INSERT INTO audit_logs(actor_id,action,entity_type) VALUES(?,?,?)").run(req.user.id,'state.saved','application_state');
      res.json({ok:true,...result});
    }catch(error){console.error('Save data error:',error.message);res.status(500).json({error:'Could not save your changes. Please retry.'});}
  });
  app.post('/api/reminders/check',requireAuth,(req,res)=>{
    try{res.json(sweepMissedDoses(db,{graceMinutes:Number(process.env.MISSED_DOSE_GRACE_MINUTES||15)}));}
    catch(error){console.error('Reminder check error:',error.message);res.status(500).json({error:'Could not check reminder status.'});}
  });
  app.patch('/api/alerts/:id/acknowledge',requireAuth,(req,res)=>{
    const id=Number(req.params.id);
    if(!Number.isSafeInteger(id)||id<1)return res.status(400).json({error:'Alert ID is invalid.'});
    try{
      const changed=acknowledgeAlert(db,req.user.id,id);
      if(!changed)return res.status(404).json({error:'Open alert was not found.'});
      db.prepare("INSERT INTO audit_logs(actor_id,action,entity_type,entity_id) VALUES(?,?,?,?)").run(req.user.id,'alert.acknowledged','alert',id);
      res.json({ok:true});
    }catch(error){console.error('Acknowledge alert error:',error.message);res.status(500).json({error:'Could not update the alert.'});}
  });
  app.get('/api/health',(req,res)=>res.json({status:'ok',database:'connected',timestamp:new Date().toISOString()}));

  app.use(express.static(path.join(__dirname,'..')));
  app.get('*',(_req,res)=>res.sendFile(path.join(__dirname,'..','index.html')));
  app.use((err,_req,res,_next)=>{
    if(err && err.type==='entity.too.large')return res.status(413).json({error:'Request is too large.'});
    if(err instanceof SyntaxError && 'body' in err)return res.status(400).json({error:'Request contains invalid JSON.'});
    console.error('Unhandled request error:',err);
    res.status(500).json({error:'An unexpected server error occurred.'});
  });
  app.locals.db=db;
  return app;
}
module.exports={createApp};
