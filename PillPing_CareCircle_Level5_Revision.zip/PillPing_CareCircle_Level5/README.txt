PillPing — Full Stack Level 3


WHAT'S NEW
- Node.js + Express API backend
- SQLite persistent database (data is stored on the server)
- Account creation and login (passwords hashed with bcrypt)
- Session-based authentication and per-account data separation
- Server-side validation for medicine schedule data
- Basic security headers and limited JSON request size
- Modular backend file (backend/app.js)
- Automated backend tests for health, registration/login, data persistence and validation
- Preserved frontend design, patient/caregiver views, medicine tracking, reminder UI, reports, CSV and print/PDF export


HOW TO RUN
1. Install Node.js 22 LTS (v22.23.5 is suitable).
2. Extract this ZIP.
3. Open a terminal in the PillPing_HTML_CSS_JS folder.
4. Install dependencies:
   npm install
5. Start the app:
   npm start
6. Open http://localhost:3000 in your browser.
7. Create an account with a valid email and a password of at least 8 characters.

TESTS
Run:
   npm test  (API tests plus validation and priority algorithm tests)


PROJECT STRUCTURE
- index.html                 Frontend layout and sign-in/register screen
- css/style.css             Responsive styling
- js/app.js                 Frontend application and API calls
- server.js                 Server entry point
- backend/app.js             Express routes, authentication, SQLite database, validation
- tests/backend.test.js      Automated tests
- data/pillping.sqlite      Created automatically at first launch


SECURITY / DEMO NOTES
- Use a strong SESSION_SECRET environment variable before deployment.
- Set secureCookies true behind HTTPS for production (the included local setup is HTTP).
- Express's default session store is for local demonstration only; production should use a persistent session store.
- This project is a student demo and is not a clinical system. Do not enter real medical or personal data.
- Browser notification/reminder timing remains limited while the browser is open. This build does not send SMS/email/phone alerts.
- Do not deploy this demo publicly without a proper review of security, privacy, backups, and session handling.
